#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <md4c.h>

// Структуры для AST
struct ASTNode {
    enum Type {
        DOC,
        PARAGRAPH,
        HEADING,
        CODE_BLOCK,
        LIST,
        LIST_ITEM,
        EMPHASIS,
        STRONG,
        CODE,
        TEXT,
        LINE_BREAK,
        LINK,
        IMAGE
    } type;
    
    std::string text;
    int heading_level = 0;
    std::string url;
    std::string title;
    std::vector<std::shared_ptr<ASTNode>> children;
    
    ASTNode(Type t) : type(t) {}
};

class MarkdownParser {
private:
    std::shared_ptr<ASTNode> root;
    std::shared_ptr<ASTNode> current;
    std::vector<std::shared_ptr<ASTNode>> stack;
    std::string temp_text;
    
public:
    MarkdownParser() {
        root = std::make_shared<ASTNode>(ASTNode::DOC);
        current = root;
    }
    
    // Callback для открытия блока
    static int block_enter_callback(MD_BLOCKTYPE type, void* detail, void* userdata) {
        MarkdownParser* parser = static_cast<MarkdownParser*>(userdata);
        return parser->on_block_enter(type, detail);
    }
    
    // Callback для закрытия блока
    static int block_exit_callback(MD_BLOCKTYPE type, void* detail, void* userdata) {
        MarkdownParser* parser = static_cast<MarkdownParser*>(userdata);
        return parser->on_block_exit(type, detail);
    }
    
    // Callback для открытия спана (встроенного элемента)
    static int span_enter_callback(MD_SPANTYPE type, void* detail, void* userdata) {
        MarkdownParser* parser = static_cast<MarkdownParser*>(userdata);
        return parser->on_span_enter(type, detail);
    }
    
    // Callback для закрытия спана
    static int span_exit_callback(MD_SPANTYPE type, void* detail, void* userdata) {
        MarkdownParser* parser = static_cast<MarkdownParser*>(userdata);
        return parser->on_span_exit(type, detail);
    }
    
    // Callback для текста
    static int text_callback(MD_TEXTTYPE type, const MD_CHAR* text, MD_SIZE size, void* userdata) {
        MarkdownParser* parser = static_cast<MarkdownParser*>(userdata);
        return parser->on_text(type, text, size);
    }
    
    int on_block_enter(MD_BLOCKTYPE type, void* detail) {
        std::shared_ptr<ASTNode> node;
        
        switch (type) {
            case MD_BLOCK_P:
                node = std::make_shared<ASTNode>(ASTNode::PARAGRAPH);
                break;
            case MD_BLOCK_H:
                node = std::make_shared<ASTNode>(ASTNode::HEADING);
                node->heading_level = static_cast<MD_BLOCK_H_DETAIL*>(detail)->level;
                break;
            case MD_BLOCK_CODE:
                node = std::make_shared<ASTNode>(ASTNode::CODE_BLOCK);
                break;
            case MD_BLOCK_UL:
            case MD_BLOCK_OL:
                node = std::make_shared<ASTNode>(ASTNode::LIST);
                break;
            case MD_BLOCK_LI:
                node = std::make_shared<ASTNode>(ASTNode::LIST_ITEM);
                break;
            default:
                return 0;
        }
        
        if (node) {
            current->children.push_back(node);
            stack.push_back(current);
            current = node;
        }
        
        return 0;
    }
    
    int on_block_exit(MD_BLOCKTYPE type, void* detail) {
        if (!stack.empty()) {
            current = stack.back();
            stack.pop_back();
        }
        return 0;
    }
    
    int on_span_enter(MD_SPANTYPE type, void* detail) {
        std::shared_ptr<ASTNode> node;
        
        switch (type) {
            case MD_SPAN_EM:
                node = std::make_shared<ASTNode>(ASTNode::EMPHASIS);
                break;
            case MD_SPAN_STRONG:
                node = std::make_shared<ASTNode>(ASTNode::STRONG);
                break;
            case MD_SPAN_CODE:
                node = std::make_shared<ASTNode>(ASTNode::CODE);
                break;
            case MD_SPAN_A: {
                node = std::make_shared<ASTNode>(ASTNode::LINK);
                MD_SPAN_A_DETAIL* link_detail = static_cast<MD_SPAN_A_DETAIL*>(detail);
                node->url = std::string(link_detail->href.text, link_detail->href.size);
                if (link_detail->title.size > 0) {
                    node->title = std::string(link_detail->title.text, link_detail->title.size);
                }
                break;
            }
            case MD_SPAN_IMG: {
                node = std::make_shared<ASTNode>(ASTNode::IMAGE);
                MD_SPAN_IMG_DETAIL* img_detail = static_cast<MD_SPAN_IMG_DETAIL*>(detail);
                node->url = std::string(img_detail->src.text, img_detail->src.size);
                if (img_detail->title.size > 0) {
                    node->title = std::string(img_detail->title.text, img_detail->title.size);
                }
                break;
            }
            default:
                return 0;
        }
        
        if (node) {
            current->children.push_back(node);
            stack.push_back(current);
            current = node;
        }
        
        return 0;
    }
    
    int on_span_exit(MD_SPANTYPE type, void* detail) {
        if (!stack.empty()) {
            current = stack.back();
            stack.pop_back();
        }
        return 0;
    }
    
    int on_text(MD_TEXTTYPE type, const MD_CHAR* text, MD_SIZE size) {
        std::string content(text, size);
        
        auto node = std::make_shared<ASTNode>(ASTNode::TEXT);
        node->text = content;
        current->children.push_back(node);
        
        return 0;
    }
    
    std::shared_ptr<ASTNode> parse(const std::string& markdown) {
        MD_PARSER parser = {
            0,
            MD_FLAG_TABLES,
            block_enter_callback,
            block_exit_callback,
            span_enter_callback,
            span_exit_callback,
            text_callback,
            nullptr,
            nullptr
        };
        
        md_parse(markdown.c_str(), markdown.size(), &parser, this);
        
        return root;
    }
};

void print_ast(const std::shared_ptr<ASTNode>& node, int depth = 0) {
    if (!node) return;
    
    std::string indent(depth * 2, ' ');
    
    switch (node->type) {
        case ASTNode::DOC:
            std::cout << indent << "DOC\n";
            break;
        case ASTNode::PARAGRAPH:
            std::cout << indent << "PARAGRAPH\n";
            break;
        case ASTNode::HEADING:
            std::cout << indent << "HEADING (level " << node->heading_level << ")\n";
            break;
        case ASTNode::CODE_BLOCK:
            std::cout << indent << "CODE_BLOCK: " << node->text << "\n";
            break;
        case ASTNode::LIST:
            std::cout << indent << "LIST\n";
            break;
        case ASTNode::LIST_ITEM:
            std::cout << indent << "LIST_ITEM\n";
            break;
        case ASTNode::EMPHASIS:
            std::cout << indent << "EMPHASIS\n";
            break;
        case ASTNode::STRONG:
            std::cout << indent << "STRONG\n";
            break;
        case ASTNode::CODE:
            std::cout << indent << "CODE: " << node->text << "\n";
            break;
        case ASTNode::TEXT:
            std::cout << indent << "TEXT: \"" << node->text << "\"\n";
            break;
        case ASTNode::LINK:
            std::cout << indent << "LINK (url: " << node->url << ")\n";
            break;
        case ASTNode::IMAGE:
            std::cout << indent << "IMAGE (src: " << node->url << ")\n";
            break;
        default:
            std::cout << indent << "UNKNOWN\n";
    }
    
    for (const auto& child : node->children) {
        print_ast(child, depth + 1);
    }
}

int main() {
    std::string markdown = R"(
# Заголовок первого уровня

Это **жирный текст** и это *курсивный текст*.

## Подзаголовок

Вот код: `int x = 42;`

- Пункт 1
- Пункт 2
- Пункт 3

Ссылка на [Google](https://google.com)
)";
    
    MarkdownParser parser;
    auto ast = parser.parse(markdown);
    
    std::cout << "AST структура:\n";
    print_ast(ast);
    
    return 0;
}
